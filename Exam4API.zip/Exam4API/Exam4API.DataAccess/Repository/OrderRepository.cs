﻿using Exam4API.Data;
using Exam4API.DataAccess.Repository.IRepository;
using Exam4API.Models;
using ModelView.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam4API.DataAccess.Repository
{
    public class OrderRepository : Repository<Order>, IOrderRepository
    {
        private readonly ApplicationDbContext _db;

        public OrderRepository(ApplicationDbContext db) : base(db)
        {
            _db = db;
        }

        public void PostOrder(RequestOrderitem requestOrderitem)
        {
          //  _db.OrderItems.Where(x => x.ProductId == requestOrderitem.orderVMs.Select(y => y.PId));
        }

        public void Update(Order order)
        {
            _db.Update(order);
        }

    }
}
