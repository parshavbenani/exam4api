﻿using Exam4API.Models;
using Exam4API.Models.ViewModel;
using Exam5.DataAccess.Data;
using Exam5.DataAccess.Repository.IRepository;
using Exam5.Models;
using Exam5.Models.VM;
using ModelView.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Exam5.Models.Address;

namespace Exam5.DataAccess.Repository
{
    public class AddressRepository : IAddressRepository
    {
        private readonly ApplicationDbContext _dbContext;
       

        public AddressRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;      
        }

        public async Task<Address> AddAddress(AddressDraft address)
        {
            var addtype = 0;
            if (address.AddressType.ToLower() == "billing")
            {
                addtype = (int)Address.AddType.Billing;
            }
            else
            {
                addtype = (int)Address.AddType.Shipping;

            }
            Address add = new Address() { 
            
                AddressDetails=address.AddressDetails,                
                AddressType=addtype,
                City=address.City,
                ContactNo=address.ContactNo,
                Country=address.Country,
                ContactPerson=address.ContactPerson,
                State = address.State,
                ZipCode=address.ZipCode,
                UserId=address.UserId
            };

            _dbContext.Add(add);
            _dbContext.SaveChanges();
            return add;
        }


        public Task<Address> AddressDrafts(AddDraft addDraft)
        {
           
            throw new NotImplementedException();
         }

            public IEnumerable<Address> GetAddress()
        {
            return _dbContext.address.ToList();
        }

        public IEnumerable<aspnetusers> GetUsers()
        {
            return _dbContext.aspnetusers.ToList();          
        }
    }
}
