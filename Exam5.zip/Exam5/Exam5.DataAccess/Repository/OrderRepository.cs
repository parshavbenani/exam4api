﻿using Exam4API.Models;
using Exam5.DataAccess.Data;
using Exam5.DataAccess.Repository.IRepository;
using Exam5.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Exam5.DataAccess.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly ApplicationDbContext _dbContext;
        internal DbSet<Order> _orders;

        public OrderRepository(ApplicationDbContext dbContext, DbSet<Order> orders)
        {
            _dbContext = dbContext;
            _orders = orders;
        }

        public void Add(OrderAddress orderAddress)
        {
            _dbContext.orderaddress.Add(orderAddress);
        }

        public Order GetFirstOrDefault(Expression<Func<Order, bool>> filter)
        {
            IQueryable<Order> query = _orders;
            query = query.Where(filter);
            return query.FirstOrDefault();
        }
        public Order Update(int ordId, int status)
        {
           var data= _dbContext.orders.Find(ordId);
            data.StatusType = (StatusType)status;
          //   status = data.StatusType.
            _dbContext.SaveChanges();
            return data;
        }
      
    }
}
