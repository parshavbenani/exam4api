﻿using Exam4API.Models;
using Exam5.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Exam5.DataAccess.Repository.IRepository
{
    public interface IOrderRepository
    {
        public Order Update(int ordId,int status);

        public void Add(OrderAddress orderAddress);
        Order GetFirstOrDefault(Expression<Func<Order,bool>>filter);
    }
}
