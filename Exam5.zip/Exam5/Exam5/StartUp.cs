﻿using Exam5.DataAccess.Data;
using Exam5.DataAccess.Repository;
using Exam5.DataAccess.Repository.IRepository;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


[assembly:FunctionsStartup(typeof(Exam5.StartUp))]
namespace Exam5
{
    public class StartUp : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            string Connection = Environment.GetEnvironmentVariable("DefaultConnection");
            builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseMySql(
                Connection, ServerVersion.AutoDetect(Connection)));

            builder.Services.AddScoped<IAddressRepository, AddressRepository>();
            builder.Services.AddScoped<IOrderRepository, OrderRepository>();
        }
    }
}
