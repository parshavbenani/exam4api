using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Exam5.DataAccess.Data;
using System.Linq;
using Exam5.DataAccess.Repository;
using Exam5.DataAccess.Repository.IRepository;
using Exam5.Models;
using Exam4API.Models;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using Exam5.Models.VM;
using System.Text;

namespace Exam5
{
    public class Function1
    {
        private readonly IAddressRepository _addressRepository;
        private readonly IOrderRepository _orderRepository;
       
        public Function1(IAddressRepository addressRepository,IOrderRepository orderRepository)
        {
            _addressRepository= addressRepository;
            _orderRepository= orderRepository;
        }
      

        [FunctionName("GetAddressList")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {           
                var address1 = _addressRepository.GetAddress();            
                return new OkObjectResult(new Response { Data = address1, Status = "success" });
            }
            catch(Exception ex)
            {
                return new BadRequestObjectResult(ex.Message);
            }
            
        }

        [FunctionName("AddAddress")]
        public async Task<IActionResult> Run1(
            [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            try
            {
                var data = _addressRepository.GetUsers();

                string requestbody = await new StreamReader(req.Body).ReadToEndAsync();
                var address = JsonConvert.DeserializeObject<AddressDraft>(requestbody);

                foreach(var item in data)
                {
                    if (item.Email == address.ContactPerson)
                    {
                        address.ContactPerson = item.Email;
                        address.UserId = item.Id;
                    }                 
                }
            
      
                var Addadd = _addressRepository.AddAddress(address);
                return new OkObjectResult(new Response { Data = Addadd,Status = "Success"});
            }
            catch(Exception ex)
            {
                return new OkObjectResult(new Response { Data = ex,Status = "Faild" });
            }
          
        }

        [FunctionName("UpdateOrderStatus")]
        public async Task<IActionResult> Run2(
           [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
           ILogger log)
        {
            int orderid = int.Parse(req.Query["Oid"]);
            var status = req.Query["status"];

            var data = _orderRepository.Update(orderid,Convert.ToInt32(status));

            if(data == null)
            {
              return new OkObjectResult(new Response { Data =null ,Status = "Fail"});
               
            }
            else{
                return new OkObjectResult(new Response { Data =data , Status = "Success" });
            }

        }

        [FunctionName("CreateDraftOrder")]
        public async Task<IActionResult> Run3(
          [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequest req,
          ILogger log)
        {

             string requestbody = await new StreamReader(req.Body).ReadToEndAsync();
             var jsonobj = JObject.Parse(requestbody);
            var shippingAdd = (int)jsonobj["Shippingaddressid"];
            var BillingAdd = (int)jsonobj["Billingaddressid"];

            using (var client = new HttpClient())
            {
                var apiurl = "https://localhost:44397/api/Order/AddOrderNew OrderItem?statusType=draft";
                var jsonContent = new StringContent(requestbody,Encoding.UTF8,"application/json"); 
                var response = await client.PostAsync(apiurl,jsonContent);

                if(response.IsSuccessStatusCode)
                {
                    var responseContent = await response.Content.ReadAsStringAsync();
                    dynamic responseobject =JsonConvert.DeserializeObject<dynamic>(responseContent);
                    int Orderid = responseobject.Orderid;
                    var OrderAddress = new OrderAddress
                    {
                        OrderId = Orderid,
                        AddressId = shippingAdd
                    };
                    _orderRepository.Add(OrderAddress);
                    var billingOrderAddress = new OrderAddress
                    {
                        OrderId = Orderid,
                        AddressId = BillingAdd,
                    };
                    _orderRepository.Add(billingOrderAddress);
                    return new OkObjectResult(new {Orderid = Orderid});
                }
                else
                {
                    return new BadRequestObjectResult(response.ReasonPhrase);
                }
            }
           

            //HttpResponseMessage response = await client.PostAsJsonAsync(
            //   "https://localhost:44397/api/Order/AddOrderNew", add);
            //response.EnsureSuccessStatusCode();

         //   _addressRepository.AddressDrafts(add);

         //   return new OkObjectResult(new Response { Data = "", Status = "Success" });
           
        }


    }
}
