﻿using ExcelDataReader;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using MVCExcel.Models;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

namespace MVCExcel.Controllers
{
    public class ExcelController : Controller
    {
        static dynamic Tdata;
        public IActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Index(IFormFile file)
        {
            List<Inventory> inventory = new List<Inventory>();

            var date = "";
            var totalpurchaseqty = "";
            double totalpur_Amt = 0;
            var totalsaleqty = "";
            double totalsale_amt = 0;
            double profitloss = 0;



            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            using (var stream = file.OpenReadStream())
            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {

                    while (reader.Read()) //Each row of the file
                    {
                        inventory.Add(new Inventory
                        {
                            ProductCode = reader.GetValue(0).ToString(),
                            EventType = int.Parse(reader.GetValue(1).ToString()),
                            Quantity = int.Parse(reader[2].ToString()),
                            Price = double.Parse(reader.GetValue(3).ToString()),
                            Date = DateTime.Parse(reader.GetValue(4).ToString())
                        });

                        var month = inventory.GroupBy(x => x.Date.Month).ToList();
                        foreach(var item in month)
                        {
                            var product = inventory.GroupBy(x=>x.ProductCode).ToList();
                            foreach (var data in product)
                            {
                                foreach (var type in data)
                                {
                                    if(type.EventType == 1)
                                    {
                                        totalpurchaseqty = type.Quantity.ToString();
                                        var amount = type.Price;
                                        totalpur_Amt = Convert.ToInt32(totalpurchaseqty) * Convert.ToDouble(amount);

                                    }
                                    else
                                    {
                                        totalsaleqty= type.Quantity.ToString();
                                        var amount = type.Price;
                                        totalsale_amt = Convert.ToInt32(totalsaleqty) * amount;
                                       
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Tdata = inventory.ToList();

            return RedirectToAction("ViewPage");
        }
        public IActionResult ViewPage()
        {
            dynamic inventory = Tdata;
            return View(inventory);
        }

    }
}
